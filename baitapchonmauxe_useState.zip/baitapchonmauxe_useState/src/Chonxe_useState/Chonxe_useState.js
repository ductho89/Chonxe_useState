import React, { useState } from 'react'

export default function Chonxe_useState(props) {
  //tuple
  let [state, setState] = useState({ srcImg: `./img/car/products/black-car.jpg` })

  const changeColor = (newColor) => {
    setState({
      srcImg: `./img/car/products/${newColor}-car.jpg`
    })
  }
  return (
    <div className="container">
      <h1 className="display-4">Bài tập chọn xe useState</h1>
      <div className="row">
        <div className="col-6">
          <img src={state.srcImg} className="w-100" />
        </div>
        <div className="col-6">
          <div className="row">
            <div className="col-3">
              <button style={{ backgroundColor: 'black', cursor: 'pointer', color: '#fff' }} onClick={() => {
                changeColor('black');
              }}>black car</button>
            </div>

            <div className="col-3">
              <button style={{ backgroundColor: 'red', cursor: 'pointer' }} onClick={() => {
                changeColor('red');
              }}>red car</button>
            </div>

            <div className="col-3">
              <button style={{ backgroundColor: 'gray', cursor: 'pointer' }} onClick={() => {
                changeColor('steel');

              }}>steel car</button>
            </div>

            <div className="col-3">
              <button style={{ backgroundColor: 'silver', cursor: 'pointer' }} onClick={() => {
                changeColor('silver');

              }}>silver car</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
